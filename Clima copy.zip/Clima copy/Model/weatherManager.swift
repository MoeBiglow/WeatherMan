//
//  weatherManager.swift
//  Clima
//
//  Created by Consultant on 12/30/22.
//  Copyright © 2022 App Brewery. All rights reserved.
//

import Foundation
    //hey testing
